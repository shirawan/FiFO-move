"""Native attachments and markers that remain when this addon's tables go away."""
import hashlib
import json
import logging
from html import escape
from uuid import uuid4

from psycopg2 import DataError, IntegrityError
from odoo import SUPERUSER_ID, api, fields, models
from odoo.exceptions import AccessError, UserError


ARCHIVE_PREFIX = "company_financial_cutover.archive."
PURCHASE_PREFIX = "company_financial_cutover.purchase."
DESCRIPTION_PREFIX = "FiFO-move protected archive: "
_ARCHIVE_TOKEN = object()
_logger = logging.getLogger(__name__)
ISSUE_PREFIX = "company_financial_cutover.recovery_issue."

BASE_FIELDS = ("source_company_id", "target_company_id", "cutover_date", "journal_id",
    "retained_earnings_account_id", "offset_account_id", "include_financial", "include_purchase_history", "include_source_branches",
    "destination_mode", "existing_data_reviewed", "prior_opening_move_ids")
AUDIT_FIELDS = ("name", "state", "snapshot_hash", "move_id", "completed_at", "completed_by", "summary", "check_status", "check_report", "completed_source_ids", "correction_move_ids", "destination_balance_preview")
LINE_FIELDS = ("sequence", "source_account_id", "target_account_id", "source_line_id", "source_date",
    "source_partner_id", "target_partner_id", "currency_id", "balance", "amount_currency", "date_maturity", "label", "kind", "posted_line_id")
HISTORY_FIELDS = ("source_company_id", "source_order_res_id", "name", "vendor_name", "original_state", "source_company_name",
    "order_date", "currency_id", "amount_total", "snapshot", "target_order_id", "replacement_vendor_id")
OPENING_FIELDS = ("name", "ref", "date", "company_id", "currency_id", "journal_id", "move_type")
OPENING_LINE_FIELDS = ("sequence", "name", "account_id", "partner_id", "date", "date_maturity",
    "debit", "credit", "balance", "amount_currency", "currency_id", "company_id", "display_type",
    "tax_line_id", "tax_repartition_line_id", "analytic_distribution")


def archive_values(record, names):
    return {name: record[name].id if record._fields[name].type == "many2one" else
        record[name].ids if record._fields[name].type in {"many2many", "one2many"} else record[name] for name in names}


def purchase_marker_key(source_company, source_order):
    return "%s%s.%s" % (PURCHASE_PREFIX, source_company, source_order)


class FinancialCutover(models.Model):
    _inherit = "company.financial.cutover"

    archive_key = fields.Char(readonly=True, copy=False)
    archive_attachment_id = fields.Many2one("ir.attachment", readonly=True, copy=False, ondelete="restrict")
    report_attachment_id = fields.Many2one("ir.attachment", readonly=True, copy=False, ondelete="restrict")
    _unique_archive = models.Constraint("UNIQUE(archive_key)", "This completed move already has an archive.")

    def action_apply(self):
        with self.env.cr.savepoint():
            result = super().action_apply()
            self._save_durable_archive()
            return result

    def _archive_payload(self):
        return {
            "version": 1, "archive_key": self.archive_key,
            "companies": {"old": self.source_company_id.name, "new": self.target_company_id.name},
            "settings": archive_values(self, BASE_FIELDS), "audit": archive_values(self, AUDIT_FIELDS),
            "accounts": [archive_values(row, ("source_account_id", "target_account_id", "handled_by_stock")) for row in self.mapping_ids],
            "contacts": [archive_values(row, ("source_partner_id", "target_partner_id", "create_contact")) for row in self.partner_mapping_ids],
            "lines": [archive_values(row, LINE_FIELDS) for row in self.line_ids],
            "purchases": self._archive_purchase_rows(),
            "opening": self._opening_evidence(self.move_id) if self.move_id else False,
            "corrections": [self._opening_evidence(move) for move in self.correction_move_ids.sorted("id")],
            "earlier_openings": [self._opening_evidence(move) for move in self.prior_opening_move_ids.sorted("id")],
            "copied_documents": [self._opening_evidence(move) for move in self.copied_invoice_ids.target_move_id.sorted("id")],
            "copied_invoices": [archive_values(pair, ("source_move_id", "target_move_id")) for pair in self.copied_invoice_ids],
        }

    def _opening_evidence(self, move):
        evidence = {"id": move.id, **archive_values(move, OPENING_FIELDS),
            "lines": [{"id": line.id, **archive_values(line, OPENING_LINE_FIELDS),
                "tax_ids": sorted(line.tax_ids.ids), "tax_tag_ids": sorted(line.tax_tag_ids.ids)}
                for line in move.line_ids.sorted("id")]}
        # Normalize dates to the exact representation saved in JSON. Payment
        # reconciliation fields are intentionally excluded from this evidence.
        return json.loads(json.dumps(evidence, sort_keys=True, default=str))

    def _validate_archived_opening(self, payload):
        settings, audit = payload["settings"], payload["audit"]
        move = self.env["account.move"].browse(audit["move_id"]).exists()
        if not settings["include_financial"]:
            if move:
                raise UserError("A purchase-only archive unexpectedly references a financial opening. Ask your administrator to review recovery.")
            return
        changed = (not move or move.state != "posted" or move.move_type != "entry"
            or move.company_id.id != settings["target_company_id"] or move.journal_id.id != settings["journal_id"]
            or str(move.date) != str(settings["cutover_date"]))
        if not changed and payload.get("opening"):
            changed = self._opening_evidence(move) != payload["opening"]
        elif not changed:
            # Older archives have no full native signature. Validate everything
            # they did capture instead of accepting any posted entry by ID.
            rows = sorted((row for row in payload["lines"] if row["kind"] != "stock_excluded"), key=lambda row: row["sequence"])
            posted = {line.id: line for line in move.line_ids}
            changed = set(posted) != {row["posted_line_id"] for row in rows}
            for sequence, row in enumerate(rows, 1):
                line = posted.get(row["posted_line_id"])
                if not line:
                    changed = True
                    break
                if (line.account_id.id != row["target_account_id"] or line.partner_id.id != row["target_partner_id"]
                    or line.currency_id.id != row["currency_id"] or line.name != row["label"]
                    or line.sequence != sequence or str(line.date_maturity or False) != str(row["date_maturity"])
                    or not move.company_id.currency_id.is_zero(line.balance - row["balance"])
                    or not line.currency_id.is_zero(line.amount_currency - row["amount_currency"])):
                    changed = True
                    break
        for evidence in payload.get("corrections", []) + payload.get("earlier_openings", []) + payload.get("copied_documents", []):
            native = self.env["account.move"].browse(evidence["id"]).exists()
            if not native or native.state != "posted" or self._opening_evidence(native) != evidence:
                changed = True
        if changed:
            raise UserError("The archived financial opening has changed or is missing. Ask your accountant to review its date, journal and journal items before restoring migration history. Nothing was reposted.")

    def _save_durable_archive(self):
        self.ensure_one()
        if self.state != "done":
            raise UserError("Only completed moves can be archived.")
        if not self.archive_key:
            self._system_write({"archive_key": str(uuid4())})
        Parameter = self.env["ir.config_parameter"].sudo()
        previous = Parameter.search([("key", "=", ARCHIVE_PREFIX + self.archive_key)])
        if previous:
            if Parameter.get_param(ISSUE_PREFIX + self.archive_key):
                raise UserError("Recover this move's saved archive before updating its completion checkpoint.")
            old_payload = self._load_durable_archive(previous)[1]
            self._validate_archived_opening(old_payload)
        payload = self._archive_payload()
        raw = json.dumps(payload, sort_keys=True, default=str).encode()
        html = ("<!doctype html><html><meta charset='utf-8'><title>Completed company move</title><body>"
            "<h1>Completed company move: %s</h1><p>%s → %s</p><p>%s</p>"
            % tuple(escape(str(v)) for v in (self.name, self.source_company_id.name, self.target_company_id.name, self.summary or "")))
        if self.destination_balance_preview:
            html += "<h2>Balances in the new company</h2><table><tr><th>Account</th><th>Already here</th><th>Carried opening</th><th>Earlier opening adjustment</th><th>After this move</th></tr>"
            for row in self.destination_balance_preview:
                html += "<tr>" + "".join("<td>%s</td>" % escape(str(row[key])) for key in ("account", "before", "added", "removed", "after")) + "</tr>"
            html += "</table>"
        if self.correction_move_ids:
            html += "<p>Posted adjustments: %s</p>" % escape(", ".join(self.correction_move_ids.mapped("display_name")))
        html += "<h2>Financial amounts</h2><table><tr><th>Description</th><th>Amount</th><th>Currency</th></tr>"
        for line in self.line_ids:
            html += "<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % tuple(escape(str(v)) for v in (line.label, line.balance, self.currency_id.name))
        html += "</table><h2>Purchase history</h2>"
        html += self._archive_purchase_report(payload["purchases"])
        html = (html + "</body></html>").encode()
        if "company.financial.purchase.history" not in self.env and payload["purchases"] and self.report_attachment_id:
            # Preserve the detailed purchase report when its optional UI is absent.
            html = self.report_attachment_id.sudo().raw
        Attachment = self.env["ir.attachment"].sudo()
        for field, content, suffix, mimetype in (
            ("archive_attachment_id", raw, "recovery.json", "application/json"),
            ("report_attachment_id", html, "report.html", "text/html"),
        ):
            values = {"name": "%s-%s" % (self.name.replace("/", "-"), suffix),
                "raw": content, "mimetype": mimetype, "public": False,
                # Standalone native attachments are administrator/creator-only.
                # Neither their data nor their access depends on custom models.
                "res_model": False, "res_id": False, "company_id": self.target_company_id.id,
                "description": DESCRIPTION_PREFIX + self.archive_key}
            attachment = self[field].sudo()
            if attachment:
                attachment._write_move_archive(values)
            else:
                attachment = Attachment._create_move_archive(values)
                self._system_write({field: attachment.id})
        Parameter = self.env["ir.config_parameter"].sudo()
        manifest = {"version": 1, "archive_key": self.archive_key,
            "attachment_id": self.archive_attachment_id.id, "sha256": hashlib.sha256(raw).hexdigest(),
            "report_id": self.report_attachment_id.id, "report_sha256": hashlib.sha256(html).hexdigest(),
            "target_company_id": self.target_company_id.id, "source_company_id": self.source_company_id.id}
        Parameter.set_param(ARCHIVE_PREFIX + self.archive_key, json.dumps(manifest, sort_keys=True))
        self._save_purchase_markers()

    def _read_purchase_marker(self, parameter):
        try:
            value = json.loads(parameter.value)
            if value["version"] != 1 or not value["archive_key"] or not isinstance(value["target_company_id"], int):
                raise ValueError()
            return value
        except (KeyError, ValueError, TypeError):
            raise UserError("An existing purchase migration marker is unreadable. Ask your administrator to recover its archive; no duplicate will be created.") from None

    def _load_durable_archive(self, parameter):
        try:
            manifest = json.loads(parameter.value)
            attachment = self.env["ir.attachment"].sudo().browse(manifest["attachment_id"]).exists()
            raw = attachment.raw if attachment else b""
            if (not raw or hashlib.sha256(raw).hexdigest() != manifest["sha256"]
                or manifest["version"] != 1 or parameter.key != ARCHIVE_PREFIX + manifest["archive_key"]):
                raise ValueError()
            report = self.env["ir.attachment"].sudo().browse(manifest["report_id"]).exists()
            if not report or hashlib.sha256(report.raw).hexdigest() != manifest["report_sha256"]:
                raise ValueError()
            payload = json.loads(raw)
            if (payload["version"] != 1 or payload["archive_key"] != manifest["archive_key"]
                or payload["settings"]["target_company_id"] != manifest["target_company_id"]
                or payload["settings"]["source_company_id"] != manifest["source_company_id"]
                or payload["audit"]["state"] != "done"):
                raise ValueError()
            return manifest, payload
        except (KeyError, ValueError, TypeError):
            raise UserError("A saved migration archive is missing or changed. Ask your administrator to restore the archive from backup before reinstalling or copying data again.") from None

    def _archive_completed(self):
        companies = self.env["res.company"].sudo().with_context(active_test=False).search([])
        batches = self.sudo().with_context(allowed_company_ids=companies.ids).search([("state", "=", "done")])
        for batch in batches:
            if batch.archive_key and self.env['ir.config_parameter'].sudo().get_param(ISSUE_PREFIX + batch.archive_key):
                _logger.info("Kept pending archive %s unchanged during checkpoint", batch.archive_key)
                continue
            try:
                with self.env.cr.savepoint():
                    batch._save_durable_archive()
            except UserError as exc:
                Parameter = self.env["ir.config_parameter"].sudo()
                if not batch.archive_key or not Parameter.search([("key", "=", ARCHIVE_PREFIX + batch.archive_key)]):
                    raise  # Never remove history that has no durable checkpoint.
                # Keep old evidence rather than adopting a changed opening/copy.
                Parameter.set_param(ISSUE_PREFIX + batch.archive_key, str(exc))
                self.env["company.financial.recovery.issue"]._record_issue(batch.archive_key, str(exc))
                _logger.warning("Kept original archive %s during checkpoint: %s", batch.archive_key, exc)

    def _archive_purchase_rows(self):
        # Preserve purchase evidence when its optional addon is not installed.
        if self.archive_key:
            parameter = self.env["ir.config_parameter"].sudo().search([("key", "=", ARCHIVE_PREFIX + self.archive_key)])
            if parameter:
                return self._load_durable_archive(parameter)[1].get("purchases", [])
        return []

    def _archive_purchase_report(self, rows):
        return "".join("<p>%s — %s; total %s. Install Company Purchase Cutover to restore the detailed history.</p>" %
            tuple(escape(str(row.get(key, ""))) for key in ("name", "vendor_name", "amount_total")) for row in rows)

    def _save_purchase_markers(self):
        return

    def _restore_purchase_rows(self, payload):
        return

    def _restore_archives(self, strict=True, archive_keys=None):
        if not self.env.is_system():
            raise AccessError("Only the administrator can restore migration archives.")
        Parameter = self.env["ir.config_parameter"].sudo()
        domain = [("key", "=like", ARCHIVE_PREFIX + "%")]
        if archive_keys is not None:
            domain = [("key", "in", [ARCHIVE_PREFIX + key for key in archive_keys])]
        for parameter in Parameter.search(domain, order="id"):
            key = parameter.key[len(ARCHIVE_PREFIX):]
            try:
                with self.env.cr.savepoint():
                    self._restore_one_archive(parameter)
            except (UserError, KeyError, ValueError, TypeError, DataError, IntegrityError) as exc:
                if strict:
                    raise
                reason = str(exc) if isinstance(exc, UserError) else "The archive has an invalid record structure. Restore its original copy from backup."
                Parameter.set_param(ISSUE_PREFIX + key, reason)
                self.env["company.financial.recovery.issue"]._record_issue(key, reason)
                _logger.warning("Migration archive %s needs recovery: %s", key, reason)
            else:
                Parameter.search([("key", "=", ISSUE_PREFIX + key)]).unlink()
                self.env["company.financial.recovery.issue"]._resolve_issue(key)
        # Pending issues are durable too, and return after an uninstall/reinstall.
        for issue in Parameter.search([("key", "=like", ISSUE_PREFIX + "%")]):
            self.env["company.financial.recovery.issue"]._record_issue(issue.key[len(ISSUE_PREFIX):], issue.value)

    def _restore_one_archive(self, parameter):
        manifest, payload = self._load_durable_archive(parameter)
        settings = payload["settings"]
        companies = self.env["res.company"].sudo().browse(list(set((payload["audit"].get("completed_source_ids") or [settings["source_company_id"]]) + [settings["target_company_id"]]))).exists()
        if len(companies) != len(set((payload["audit"].get("completed_source_ids") or [settings["source_company_id"]]) + [settings["target_company_id"]])):
            raise UserError("A company referenced by a completed migration archive no longer exists. Keep its archive and ask your administrator to review recovery.")
        all_companies = self.env["res.company"].sudo().with_context(active_test=False).search([])
        Cutover = self.with_user(SUPERUSER_ID).with_context(allowed_company_ids=all_companies.ids)
        batch = Cutover.search([("archive_key", "=", payload["archive_key"])])
        Cutover._validate_archived_opening(payload)
        if batch:
            batch._restore_purchase_rows(payload)
            return batch
        values = {key: settings[key] for key in BASE_FIELDS if key in settings}
        if "prior_opening_move_ids" in values:
            values["prior_opening_move_ids"] = [(6, 0, values["prior_opening_move_ids"])]
        batch = Cutover.create(values)
        for name, model, rows in (
            ("accounts", "company.financial.account.mapping", payload["accounts"]),
            ("contacts", "company.financial.partner.mapping", payload["contacts"]),
        ):
            for row in rows:
                batch.env[model].create({**row, "cutover_id": batch.id})
        for pair in payload.get("copied_invoices", []):
            batch.env["company.financial.copied.invoice"].create({**pair, "cutover_id": batch.id})
        if payload["lines"]:
            batch.env["company.financial.cutover.line"]._system_create([
                {**row, "cutover_id": batch.id} for row in payload["lines"]])
        audit = {key: payload["audit"][key] for key in AUDIT_FIELDS if key in payload["audit"]}
        if "correction_move_ids" in audit:
            audit["correction_move_ids"] = [(6, 0, audit["correction_move_ids"])]
        batch._system_write({**audit, "archive_key": payload["archive_key"],
            "archive_attachment_id": manifest["attachment_id"], "report_attachment_id": manifest["report_id"]})
        if batch.move_id or batch.correction_move_ids:
            (batch.move_id | batch.correction_move_ids)._restore_financial_cutover_link(batch.id)
        batch._restore_purchase_rows(payload)
        return batch

    def action_download_move_report(self):
        self.ensure_one()
        self._operator()
        if not self.report_attachment_id:
            self._save_durable_archive()
        return {"type": "ir.actions.act_url", "url": "/web/content/%s?download=1" % self.report_attachment_id.id, "target": "self"}


class Attachment(models.Model):
    _inherit = "ir.attachment"

    @api.model_create_multi
    def create(self, values_list):
        if self.env.context.get("_fifo_archive_token") is not _ARCHIVE_TOKEN and any(
            str(values.get("description") or "").startswith(DESCRIPTION_PREFIX) for values in values_list):
            raise AccessError("Migration archives are system-managed.")
        return super().create(values_list)

    def write(self, values):
        if self.env.context.get("_fifo_archive_token") is not _ARCHIVE_TOKEN and (
            any(str(row.description or "").startswith(DESCRIPTION_PREFIX) for row in self)
            or str(values.get("description") or "").startswith(DESCRIPTION_PREFIX)):
            raise AccessError("Keep completed migration archives unchanged.")
        return super().write(values)

    def unlink(self):
        if any(str(row.description or "").startswith(DESCRIPTION_PREFIX) for row in self):
            raise AccessError("Keep completed migration archives. They protect against duplicates after reinstalling.")
        return super().unlink()

    def _create_move_archive(self, values):
        return self.with_context(_fifo_archive_token=_ARCHIVE_TOKEN).create(values).with_env(self.env)

    def _write_move_archive(self, values):
        return self.with_context(_fifo_archive_token=_ARCHIVE_TOKEN).write(values)
