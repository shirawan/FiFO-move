"""Independent financial and purchase choices over the guided move."""
import hashlib
import json

from odoo import api, fields, models
from odoo.exceptions import UserError


class FinancialCutover(models.Model):
    _inherit = "company.financial.cutover"

    include_purchase_history = fields.Boolean(string="Purchase orders (read-only history)", default=False,
        help="Requires the optional Company Purchase Cutover addon. Copies all orders, including historical and cancelled orders, as saved history.")
    purchase_preview_data = fields.Json(readonly=True, copy=False)
    purchase_preview_html = fields.Html(compute="_compute_purchase_preview", sanitize=True)
    purchase_history_preview_ready = fields.Boolean(readonly=True, copy=False)
    purchase_mover_available = fields.Boolean(compute="_compute_purchase_available")

    def _compute_purchase_available(self):
        for batch in self:
            batch.purchase_mover_available = "company.financial.purchase.history" in self.env

    @api.depends("purchase_preview_data")
    def _compute_purchase_preview(self):
        for batch in self:
            batch.purchase_preview_html = "<p>Ask your administrator to install the optional Company Purchase Cutover addon to move purchase history.</p>"

    def _invalidate_preview(self):
        super()._invalidate_preview()
        self._system_write({"purchase_preview_data": False, "purchase_history_preview_ready": False})

    def _purchase_plan(self):
        if self.include_purchase_history:
            raise UserError("Install the optional Company Purchase Cutover addon to move purchase orders. Choose Financial balances to move accounting only.")
        return []

    def _purchase_contacts(self):
        self._purchase_plan()
        return self.env["res.partner"]

    include_financial = fields.Boolean(string="Financial balances and unpaid items", default=True,
        help="Create the financial opening in a fresh company. Turn this off to copy purchase history without changing accounting.")
    move_scope = fields.Selection([
        ("financial", "Financial balances and unpaid items"),
        ("purchase", "Purchase orders (read-only history)"),
        ("both", "Financial balances and purchase orders"),
        ("stock", "Stock (separate guided move)"),
    ], string="Selected data", compute="_compute_move_scope", inverse="_inverse_move_scope", required=True,
        help="Choose one option. The screen shows only the setup needed for your selection.")
    move_scope_description = fields.Char(compute="_compute_scope_description")
    stock_mover_available = fields.Boolean(compute="_compute_stock_mover_available")

    @api.depends("include_financial", "include_purchase_history")
    def _compute_move_scope(self):
        for batch in self:
            batch.move_scope = {
                (True, True): "both", (True, False): "financial",
                (False, True): "purchase", (False, False): "stock",
            }[(bool(batch.include_financial), bool(batch.include_purchase_history))]

    def _inverse_move_scope(self):
        for batch in self:
            if batch.move_scope not in {"financial", "purchase", "both", "stock"}:
                raise UserError("Choose what you want to move.")
            batch.write({"include_financial": batch.move_scope in {"financial", "both"},
                "include_purchase_history": batch.move_scope in {"purchase", "both"}})

    @api.onchange("move_scope")
    def _onchange_move_scope(self):
        # Only update the virtual form here. The inverse invalidates the saved
        # review on save; changing a dropdown must not delete persisted rows.
        for batch in self:
            scope = batch.move_scope
            batch.include_financial = scope in {"financial", "both"}
            batch.include_purchase_history = scope in {"purchase", "both"}
            if batch.state != "done":
                batch.state = "draft"
                batch.check_status = "unchecked"
                batch.check_report = False
                batch.summary = False
                batch.snapshot_hash = False
                batch.purchase_preview_data = False
                batch.purchase_history_preview_ready = False
                batch.line_ids = False

    @api.depends("move_scope")
    def _compute_scope_description(self):
        descriptions = {
            "financial": "Move opening balances and individual unpaid customer/vendor items. Purchase orders stay in the old company.",
            "purchase": "Copy purchase orders as read-only history. Accounting balances stay unchanged. Eligible orders can be prepared as replacement drafts later.",
            "both": "Move opening balances and unpaid items, and copy purchase orders as read-only history. Stock can be moved afterwards.",
            "stock": "Open the stock mover to choose warehouses and review quantities and values. This screen will not move financial balances or purchase history.",
        }
        for batch in self:
            batch.move_scope_description = descriptions.get(batch.move_scope, "Choose what you want to move.")

    def _compute_stock_mover_available(self):
        for batch in self:
            batch.stock_mover_available = "company.stock.warehouse.cutover" in self.env

    def _validate_purchase_only(self):
        self.ensure_one()
        self._operator()
        issues = []
        if self.state == "done":
            issues.append("This move is already completed. Use Review missing purchase orders to add only missing history.")
        if self.source_company_id == self.target_company_id:
            issues.append("Choose different old and new companies.")
        if not self.include_purchase_history:
            issues.append("Choose financial balances, purchase orders, or both. For stock only, use Open stock mover below.")
        if (self.source_company_id.sudo().all_child_ids and not self.include_source_branches) or self.target_company_id.sudo().parent_id or self.target_company_id.sudo().all_child_ids:
            issues.append("Choose Include old branches to carry their branch balances together. The new company must be standalone.")

        self._raise_issues("Review these purchase-copy requirements together:", issues)

    def _plan(self):
        if self.include_financial:
            rows, digest, count = super()._plan()
            return rows, hashlib.sha256(json.dumps([digest, True]).encode()).hexdigest(), count
        self._validate_purchase_only()
        purchases = self._purchase_plan()
        evidence = [False, self.include_purchase_history, self.source_company_id.id,
            self.target_company_id.id, self._scope_evidence(), purchases]
        return [], hashlib.sha256(json.dumps(evidence, sort_keys=True, default=str).encode()).hexdigest(), 0

    def _check_purchase_only(self, build_preview=False):
        report = ["Purchase orders only: financial balances, invoices, bills and stock will not be changed."]
        try:
            self._validate_purchase_only()
            vendors = self._purchase_contacts()
            self._match_contacts(vendors)
            plan = self._plan()
        except UserError as exc:
            status = "blocked"
            report.append("Needs attention: %s" % exc)
        else:
            status = "ready"
            report.append("Purchase checks passed. Already copied orders are skipped.")
            missing = self.partner_mapping_ids.filtered(lambda row: row.source_partner_id in vendors and not row.target_partner_id)
            if missing:
                report.append("Vendors needing a choice: %s. History can be copied now. Choose these vendors from "
                    "the saved history when preparing replacement orders, before cancelling their originals." % len(missing))
        notices = self._review_notices(self.env["account.move.line"])
        if notices:
            report.append("For review — these notices do not block copying:\n" + "\n".join("• " + note for note in notices))
        self._system_write({"check_status": status, "check_report": "\n\n".join(report)})
        if status == "ready" and build_preview:
            self._store_preview(plan)
        elif status == "ready" and not self._purchase_plan():
            self._mark_up_to_date()
        return True

    def action_preview(self):
        if self.include_financial:
            return super().action_preview()
        self.ensure_one()
        self._operator()
        self._store_preview(self._plan())
        return True

    def _mark_up_to_date(self):
        self._system_write({"state": "draft", "check_status": "up_to_date",
            "check_report": "Already up to date — no new purchase history to copy. Existing copies are kept; nothing was created.",
            "snapshot_hash": False, "purchase_preview_data": [], "summary": False})

    def _store_preview(self, plan):
        if self.include_financial:
            return super()._store_preview(plan)
        _rows, digest, _count = plan
        purchases = self._purchase_plan()
        if not purchases:
            self._mark_up_to_date()
            return
        self.line_ids._system_unlink()
        self._system_write({"state": "preview", "snapshot_hash": digest,
            "purchase_preview_data": purchases,
            "summary": "%s new purchase orders will be copied as read-only history. Financial balances, receipts and bills will not be created. Already copied orders are skipped." % len(purchases)})

    def action_apply(self):
        if self.include_financial:
            return super().action_apply()
        self.ensure_one()
        self._operator()
        with self.env.cr.savepoint():
            self._lock()
            if self.state != "preview":
                raise UserError("Build and review a fresh Preview before confirming.")
            _rows, digest, _count = self._plan()
            if digest != self.snapshot_hash:
                raise UserError("The selected data changed. Build a fresh Preview before moving.")
            if not self._purchase_plan():
                self._mark_up_to_date()
                return True
            self._create_purchase_history(self.purchase_preview_data or [])
            self._system_write({"state": "done", "completed_at": fields.Datetime.now(), "completed_by": self.env.user.id})
        return {"type": "ir.actions.act_window", "name": "Completed company move",
            "res_model": self._name, "res_id": self.id, "view_mode": "form"}

    def action_open_stock_mover(self):
        self.ensure_one()
        self._operator()
        if self.source_company_id == self.target_company_id:
            raise UserError("Choose different old and new companies.")
        if "company.stock.warehouse.cutover" not in self.env:
            raise UserError("Stock moves need Company Stock Cutover and its dependencies. Ask your Odoo administrator to install them first.")
        if self.include_financial and self.state != "done":
            raise UserError("Complete the selected financial opening first, then open the stock mover. To move only stock, select Stock in the Move choice.")
        action = self.env.ref("company_stock_fifo_migration.whole_warehouse_cutover_action").read()[0]
        action.update({"views": [(False, "form")], "context": {
            **self.env.context, "default_source_company_id": self.source_company_id.id,
            "default_target_company_id": self.target_company_id.id}})
        return action
