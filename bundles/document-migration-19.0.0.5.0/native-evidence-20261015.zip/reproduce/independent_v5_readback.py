"""Independent SQL-only readback of the committed disposable v5 survival fixture."""
import datetime
import json
from decimal import Decimal
from pathlib import Path
import psycopg2
from psycopg2 import sql

root = Path('/workspace/fifo-document-work/evidence')
scenario = json.loads((root / 'archive-simulation.json').read_text())
conn = psycopg2.connect(dbname='fifo_doc_archive_survival', host='/workspace/fifo-document-work/runtime/socket', port=55433, user='agent')
conn.set_session(readonly=True, autocommit=False)
cur = conn.cursor()
target = scenario['target']
cur.execute('SELECT account_id, SUM(balance) FROM account_move_line WHERE company_id=%s AND parent_state=%s GROUP BY account_id', (target, 'posted'))
balances = dict(cur.fetchall())
trial = {name: float(balances.get(identifier, 0)) for name, identifier in scenario['accounts'].items()}
assert trial == scenario['expected_final_ledger'], trial
assert sum(balances.values()) == 0

counts = {}
for model, rows in scenario['stock_evidence'].items():
    names = scenario['stock_models'][model]
    query = sql.SQL('SELECT {} FROM {} WHERE id=%s').format(sql.SQL(', ').join(map(sql.Identifier, names)), sql.Identifier(model.replace('.', '_')))
    for saved in rows:
        cur.execute(query, (saved['id'],))
        row = cur.fetchone()
        assert row is not None, (model, saved['id'])
        for field, actual in zip(names, row):
            expected = saved[field]
            if isinstance(expected, list):
                expected = expected[0]
            if isinstance(actual, datetime.datetime):
                actual = str(actual)
            if isinstance(actual, Decimal):
                actual = float(actual)
            if actual is None:
                actual = False
            assert actual == expected, (model, saved['id'], field, actual, expected)
    counts[model] = len(rows)

bill_targets = []
for source in scenario['source_bills']:
    key = 'company_document_cutover.link.account.move.%s.%s' % (source, target)
    cur.execute('SELECT value FROM ir_config_parameter WHERE key=%s', (key,))
    marker = json.loads(cur.fetchone()[0])
    destination = marker['target']
    assert marker['purchase_history_references']
    cur.execute('SELECT company_id, state, amount_total FROM account_move WHERE id=%s', (destination,))
    company, state, total = cur.fetchone()
    cur.execute('SELECT amount_total FROM account_move WHERE id=%s', (source,))
    assert (company, state, total) == (target, 'posted', cur.fetchone()[0])
    cur.execute('SELECT COUNT(*) FROM account_move_line WHERE move_id=%s AND purchase_line_id IS NOT NULL', (destination,))
    assert cur.fetchone()[0] == 0
    bill_targets.append(destination)
assert len(set(bill_targets)) == len(bill_targets)

cur.execute('SELECT id FROM purchase_order WHERE company_id=%s ORDER BY id', (target,))
target_orders = [r[0] for r in cur.fetchall()]
assert len(target_orders) == 3
cur.execute('SELECT COUNT(*) FROM company_document_purchase_archive WHERE source_order_id=%s AND company_id=%s', (scenario['source_po'], target))
assert cur.fetchone()[0] == 1
cur.execute('SELECT state FROM company_document_cutover WHERE recovery_key=%s', (scenario['recovery_key'],))
assert cur.fetchall() == [('done',)]
result = {'status': 'PASS', 'method': 'Independent SQL read-only transaction against committed synthetic survival clone',
    'database': conn.info.dbname, 'trial_balance': trial, 'ledger_balanced': True,
    'unchanged_saved_stock_rows': counts, 'audit_only_bill_targets': bill_targets,
    'audit_bill_native_purchase_links': 0, 'native_target_orders': target_orders,
    'recovered_job': 'done', 'historical_archive_rows': 1}
conn.rollback()
conn.close()
(root / 'independent-v5-readback.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
