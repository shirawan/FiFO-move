"""Committed synthetic cutover with missing receipt history and partial archive recovery."""
import json, sys
from datetime import datetime
from pathlib import Path
from odoo import Command
sys.path.insert(0, '/workspace/FiFO-move/tools')
from document_scenario import build
assert env.cr.dbname == 'fifo_doc_history'
root = Path('/workspace/fifo-document-work/evidence')
data = build(env, prefix='Audit 5 ')
e = env(context={**env.context, 'allowed_company_ids': data['companies'], 'tracking_disable': True,
    'mail_notify_force_send': False, 'no_reset_password': True})
job = e['company.document.cutover'].browse(data['job'])
source_company = job.source_company_ids.filtered(lambda c:not c.parent_id)
product = job.mapping_ids.filtered(lambda m:m.model_name == 'product.product').source_record
new_product = job._target(product)
partner = e['res.partner'].browse(data['partner'])
source = e['purchase.order'].with_company(source_company).create({'company_id': source_company.id,
    'partner_id': partner.id, 'date_order': datetime(2024, 6, 28),
    'order_line': [Command.create({'product_id': product.id, 'name': 'Historical goods with missing new-company receipts',
        'product_qty': 10, 'product_uom_id': product.uom_id.id, 'price_unit': 20, 'discount': 5,
        'tax_ids': [Command.clear()], 'date_planned': datetime(2024, 6, 29)})]})
source.button_confirm(); source.write({'date_order': datetime(2024, 6, 28), 'date_approve': datetime(2024, 6, 28)})
receipt = source.order_line.move_ids
receipt.quantity = 4; receipt.picked = True; receipt._action_done(cancel_backorder=False); receipt.date = datetime(2024, 6, 29)
returned = receipt.copy({'origin_returned_move_id': receipt.id, 'product_uom_qty': 1, 'quantity': 1,
    'location_id': receipt.location_dest_id.id, 'location_dest_id': receipt.location_id.id,
    'picking_id': False, 'state': 'draft', 'purchase_line_id': source.order_line.id, 'to_refund': True})
returned._action_confirm(); returned.picked = True; returned._action_done(); returned.date = datetime(2024, 6, 30)
expense = e['account.account'].search([('company_ids', 'in', source_company.ids), ('account_type', '=', 'expense')], limit=1)
bills = e['account.move']
for qty in (1, 2):
    source.with_company(source_company).action_create_invoice()
    bill = source.invoice_ids.filtered(lambda m:m.state == 'draft')
    bill.invoice_line_ids.write({'quantity': qty, 'account_id': expense.id})
    bill.write({'invoice_date': data['cutover'], 'date': data['cutover']}); bill.action_post(); bills |= bill
credit = e['account.move'].with_company(source_company).create({'company_id': source_company.id,
    'journal_id': bills[0].journal_id.id, 'move_type': 'in_refund', 'partner_id': partner.id,
    'invoice_date': data['cutover'], 'date': data['cutover'], 'invoice_line_ids': [Command.create({
        'name': source.order_line.name, 'product_id': product.id, 'purchase_line_id': source.order_line.id,
        'quantity': 1, 'price_unit': 20, 'discount': 5, 'account_id': expense.id, 'tax_ids': [Command.clear()]})]})
credit.action_post(); bills |= credit
location = e['stock.warehouse'].search([('company_id', '=', job.target_company_id.id)], limit=1).lot_stock_id
e['stock.quant']._update_available_quantity(new_product, location, 17)
job.batch_size = 1
source_moves = e['account.move'].search([('company_id', 'in', job.source_company_ids.ids)])
source_hashes = {str(m.id): job._fingerprint(m) for m in source_moves}
source_po_hash = job._fingerprint(source)
stock_models = {'stock.move': ['quantity','product_uom_qty','state','value','account_move_id','date','write_date'],
    'stock.move.line': ['quantity','lot_id','owner_id','package_id','write_date'],
    'stock.quant': ['quantity','reserved_quantity','location_id','lot_id','write_date'],
    'product.value': ['value','date','write_date']}
stock = {m:json.loads(json.dumps(e[m].search([], order='id').read(f), default=str)) for m,f in stock_models.items()}
e.cr.commit(); e.invalidate_all()
steps=[]
while not job.purchase_archive_ids:
    job.action_review(); assert job.state == 'ready', job.report
    if job.state == 'ready': assert 'History only: retain original documents' in job.report
    job.action_execute(); assert job.state == 'partial', job.report
    steps.append({'state': job.state, 'receipt': job.audit_attachment_id.id})
    e.cr.commit(); e.invalidate_all()
    assert len(steps) < 30
assert job._stored_link(source)['audit_only']
archive = job.purchase_archive_ids
payload = json.loads(archive.attachment_id.raw)
assert (payload['original']['lines'][0]['qty_received'], payload['original']['lines'][0]['qty_invoiced'],
    payload['original']['lines'][0]['qty_to_invoice'], payload['original']['lines'][0]['pending_supplier_delivery']) == (3,2,1,6)
assert not e['purchase.order'].search([('company_id', '=', job.target_company_id.id)])
for m, fields_ in stock_models.items(): assert stock[m] == json.loads(json.dumps(e[m].search([], order='id').read(fields_), default=str)), m
assert source_hashes == {str(m.id): job._fingerprint(m) for m in source_moves}
assert source_po_hash == job._fingerprint(source)
assert any(link.get('audit_only') for link in json.loads(job.audit_attachment_id.raw)['links'])
result = {**data, 'status': 'PASS', 'stage': 'partial-archive-retained', 'steps': steps, 'recovery_key': job.recovery_key,
    'source_po': source.id, 'source_bills': bills.ids, 'archive_attachment': archive.attachment_id.id,
    'archive_payload': archive.attachment_id.raw.decode(), 'partial_receipt': job.audit_attachment_id.id,
    'source_hashes': source_hashes, 'source_po_hash': source_po_hash, 'stock_models': stock_models, 'stock_evidence': stock,
    'expected_final_ledger': {'receivable':227, 'bank':150, 'payable':-178, 'equity':0, 'revenue':-577, 'expense':378},
    'current_stock_preserved': True, 'historical_quantities': {'ordered':10, 'received_net':3, 'billed_net':2,
        'billable_in_old_company':1, 'pending_supplier_delivery_in_old_company':6}, 'no_live_history_po_created':True}
(root/'archive-simulation.json').write_text(json.dumps(result, indent=2, default=str)+'\n')
e.cr.commit()
print('PASS: partial financial step retains missing PO/receipt audit history; source and all stock unchanged.')
