import base64,json
from pathlib import Path
assert env.cr.dbname=='fifo_doc_archive_survival'
root=Path('/workspace/fifo-document-work/evidence')
data=json.loads((root/'archive-simulation.json').read_text())
e=env(context={**env.context,'allowed_company_ids':data['companies'],'bin_size':True})
job=e['company.document.cutover'].search([('recovery_key','=',data['recovery_key'])])
assert len(job)==1 and job.state=='done'
models=['account.move','account.payment','purchase.order','stock.move','stock.move.line','stock.quant','product.value']
before={m:e[m].search([],order='id').read(['write_date']) for m in models}
job.action_execute()
history=job.purchase_archive_ids
values=history.read(['accounting_matches','saved_documents'])[0]
assert 'saved accounting document #' in values['accounting_matches']
assert base64.b64decode(history.with_context(bin_size=False).saved_documents)==data['archive_payload'].encode()
assert before=={m:e[m].search([],order='id').read(['write_date']) for m in models}
result={'status':'PASS','final_code_completed_job_retry_with_browser_context':True,
    'all_native_rows_and_write_dates_unchanged':True,'original_historical_record_bytes_unchanged':True,
    'human_readable_financial_matches_available':True,'download_content_verified':True}
(root/'archive-final-readback.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: final code reads and verifies restored native records and historical downloads without changes.')
