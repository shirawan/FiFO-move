import json,os
from pathlib import Path
assert env.cr.dbname=='fifo_doc_archive_optional_survival'
root=Path('/workspace/fifo-document-work/evidence');data=json.loads((root/'archive-simulation.json').read_text())
e=env(context={**env.context,'allowed_company_ids':eids}) if (eids:=data['companies']) else env
phase=os.environ['FIFO_OPTIONAL_PHASE']
models=['account.move','account.move.line','account.payment','purchase.order','stock.move','stock.move.line','stock.quant','product.value']
if phase=='uninstall':
    job=e['company.document.cutover'].search([('recovery_key','=',data['recovery_key'])]);assert job.state=='done'
    (root/'archive-optional-before.json').write_text(json.dumps({'job':job.id,'attachment':job.purchase_archive_ids.attachment_id.id,
        'job_states':{str(j.id):j.state for j in e['company.document.cutover'].search([])},'native_evidence':{m:e[m].search([],order='id').read(['write_date']) for m in models},'native':{m:e[m].search([],order='id').ids for m in models}},default=str))
    e['ir.module.module'].search([('name','=','company_document_purchase_cutover')]).button_immediate_uninstall();e.cr.commit()
    print('PASS optional-only uninstall')
else:
    before=json.loads((root/'archive-optional-before.json').read_text())
    assert before['native']=={m:e[m].search([],order='id').ids for m in before['native']}
    assert before['native_evidence']==json.loads(json.dumps({m:e[m].search([],order='id').read(['write_date']) for m in models},default=str))
    job=e['company.document.cutover'].browse(before['job']);assert job.exists() and job.state=='done'
    assert before['job_states']=={str(j.id):j.state for j in e['company.document.cutover'].search([])}
    if phase=='absent':
        assert 'company.document.purchase.archive' not in e
        assert e['company.document.mapping'].search_count([('model_name','in',['purchase.order','purchase.order.line','stock.move','stock.lot','stock.location','stock.package','product.value'])])==0
        print('PASS: optional addon absent, native IDs and all base-job states unchanged, optional choices safely removed.')
        raise SystemExit
    assert job.include_purchase
    assert len(job.purchase_archive_ids)==1 and job.purchase_archive_ids.attachment_id.id==before['attachment']
    job.with_context(bin_size=True).action_execute()
    native=json.loads((root/'archive-optional-native-fixture.json').read_text())
    native_job=e['company.document.cutover'].browse(native['job']);assert native_job.state=='done' and native_job.include_purchase
    assert {tuple(r) for r in native['matches']}=={(r.model_name,r.source_id,r.target_id) for r in native_job.mapping_ids}
    native_job.with_context(bin_size=True).action_execute()
    assert native_job._stored_link(e['purchase.order'].browse(native['source_order']))['target']==native['target_order']
    result={'status':'PASS','all_optional_native_match_types_restored':native['optional_models'],'optional_purchase_only_removal_and_reinstall':True,'base_job_id_retained':job.id,
        'history_screen_rebuilt':True,'original_attachment_retained':True,'all_native_ids_unchanged':True,'all_native_write_dates_unchanged':True}
    (root/'archive-optional-survival.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS optional-only reinstall')
