"""Synthetic native matches exercise optional selection cleanup during real uninstall."""
import json
from datetime import datetime
from pathlib import Path
from odoo import Command
assert env.cr.dbname=='fifo_doc_archive_optional_survival'
root=Path('/workspace/fifo-document-work/evidence');data=json.loads((root/'archive-simulation.json').read_text())
e=env(context={**env.context,'allowed_company_ids':data['companies'],'no_reset_password':True,'mail_notify_force_send':False,'tracking_disable':True})
e['company.document.cutover'].action_restore_saved_moves()
original=e['company.document.cutover'].search([('recovery_key','=',data['recovery_key'])])
assert original.include_purchase and len(original.purchase_archive_ids)==1
source=original.source_company_ids.filtered(lambda c:not c.parent_id);target=original.target_company_id
partner=e['res.partner'].browse(data['partner']);pairs=[];orders=[]
package_type=e['stock.package.type'].create({'name':'Synthetic shared type for optional removal','company_id':False})
for company in (source,target):
    product=e['product.product'].with_company(company).create({'name':'Synthetic optional tracked history',
        'company_id':company.id,'type':'consu','is_storable':True,'tracking':'lot','purchase_method':'receive',
        'standard_price':10,'taxes_id':[Command.clear()],'supplier_taxes_id':[Command.clear()]})
    lot=e['stock.lot'].create({'name':'SYNTHETIC-OPTIONAL-LOT','product_id':product.id,'company_id':company.id})
    package=e['stock.package'].create({'name':'Synthetic historical package','package_type_id':package_type.id})
    po=e['purchase.order'].with_company(company).create({'company_id':company.id,'partner_id':partner.id,
        'date_order':datetime(2024,6,28),'order_line':[Command.create({'name':'Synthetic optional tracked history',
            'product_id':product.id,'product_qty':5,'product_uom_id':product.uom_id.id,'price_unit':20,
            'date_planned':datetime(2024,6,29),'tax_ids':[Command.clear()]})]})
    po.button_confirm();po.write({'date_order':datetime(2024,6,28),'date_approve':datetime(2024,6,28)})
    movement=po.order_line.move_ids
    movement.quantity=2;movement.move_line_ids.write({'lot_id':lot.id,'result_package_id':package.id,'owner_id':partner.id})
    movement.picked=True;movement._action_done(cancel_backorder=False);movement.date=datetime(2024,6,29)
    value=e['product.value'].create({'move_id':movement.id,'value':38,'date':datetime(2024,6,29)})
    orders.append((po,product,lot,package,movement,value))
settings=original._recovery_settings();settings.pop('recovery_key');settings.update({'name':'Synthetic optional native selection survival',
    'source_company_ids':[Command.set(original.source_company_ids.ids)],'include_accounting':False,'purchase_history_mode':'native'})
job=e['company.document.cutover'].create(settings)
for row in original.mapping_ids:
    e['company.document.mapping'].create({'job_id':job.id,'source_record':'%s,%s'%(row.model_name,row.source_id),'target_record':'%s,%s'%(row.model_name,row.target_id)})
old,new=orders
pairs=list(zip(old,new))+[(old[0].order_line,new[0].order_line),(old[4].location_id,new[4].location_id),(old[4].location_dest_id,new[4].location_dest_id)]
for a,b in pairs:e['company.document.mapping'].create({'job_id':job.id,'source_record':'%s,%s'%(a._name,a.id),'target_record':'%s,%s'%(b._name,b.id)})
job.action_review();assert job.state=='ready',job.report
before={m:e[m].search([],order='id').read(['write_date']) for m in ('stock.move','stock.move.line','stock.quant','product.value','account.move','purchase.order')}
job.action_execute();assert job.state=='done',job.report
assert before=={m:e[m].search([],order='id').read(['write_date']) for m in before}
result={'status':'PASS','job':job.id,'recovery_key':job.recovery_key,'source_order':old[0].id,'target_order':new[0].id,
    'matches':[[r.model_name,r.source_id,r.target_id] for r in job.mapping_ids],
    'optional_models':['purchase.order','purchase.order.line','stock.move','stock.lot','stock.location','stock.package','product.value']}
(root/'archive-optional-native-fixture.json').write_text(json.dumps(result,indent=2)+'\n')
e.cr.commit();print('PASS: native tracked/owned/packaged/manual-value matches saved before optional-only removal.')
