"""SQL-only verification of the committed optional-addon reinstall clone."""
import json
from pathlib import Path
import psycopg2
from psycopg2 import sql

root = Path('/workspace/fifo-document-work/evidence')
before = json.loads((root / 'archive-optional-before.json').read_text())
fixture = json.loads((root / 'archive-optional-native-fixture.json').read_text())
conn = psycopg2.connect(dbname='fifo_doc_archive_optional_survival', host='/workspace/fifo-document-work/runtime/socket', port=55433, user='agent')
conn.set_session(readonly=True)
cur = conn.cursor()
counts = {}
for model, rows in before['native_evidence'].items():
    cur.execute(sql.SQL('SELECT id,write_date FROM {} ORDER BY id').format(sql.Identifier(model.replace('.', '_'))))
    actual = [{'id': identifier, 'write_date': str(date) if date else False} for identifier, date in cur.fetchall()]
    assert actual == rows, model
    counts[model] = len(rows)
cur.execute('SELECT id,state FROM company_document_cutover ORDER BY id')
assert {str(identifier): state for identifier, state in cur.fetchall()} == before['job_states']
cur.execute('SELECT include_purchase FROM company_document_cutover WHERE id=%s', (before['job'],))
assert cur.fetchone() == (True,)
cur.execute('SELECT attachment_id FROM company_document_purchase_archive WHERE job_id=%s', (before['job'],))
assert cur.fetchall() == [(before['attachment'],)]
cur.execute('SELECT model_name,source_id,target_id FROM company_document_mapping WHERE job_id=%s', (fixture['job'],))
matches = set(cur.fetchall())
assert matches == {tuple(row) for row in fixture['matches']}
assert set(fixture['optional_models']) <= {row[0] for row in matches}
result = {'status': 'PASS', 'method': 'Independent SQL read-only committed optional-addon survival clone readback',
    'unchanged_native_ids_and_write_dates': counts, 'base_job_states_retained': True,
    'audit_base_job': before['job'], 'native_matched_base_job': fixture['job'],
    'original_archive_attachment': before['attachment'],
    'restored_optional_match_models': fixture['optional_models'], 'all_saved_matches_restored_exactly': True}
conn.rollback()
conn.close()
(root / 'independent-v5-optional-readback.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
