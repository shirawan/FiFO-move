"""Actual addon removal/reinstall on a backed-up disposable synthetic clone."""
import json, os
from pathlib import Path
assert env.cr.dbname == 'fifo_doc_archive_survival'
root = Path('/workspace/fifo-document-work/evidence')
data = json.loads((root/'archive-simulation.json').read_text())
e = env(context={**env.context, 'allowed_company_ids':data['companies'], 'no_reset_password':True,
    'mail_notify_force_send':False, 'tracking_disable':True})
phase = os.environ['FIFO_ARCHIVE_PHASE']
models = ['account.move','account.payment','purchase.order','stock.move','stock.move.line','stock.quant','product.value']
if phase == 'uninstall':
    job = e['company.document.cutover'].search([('recovery_key','=',data['recovery_key'])])
    assert len(job) == 1 and job.state == 'partial'
    before = {'ids':{m:e[m].search([],order='id').ids for m in models},
        'receipt_raw':job.audit_attachment_id.raw.decode(), 'receipt':job.audit_attachment_id.id,
        'archive_raw':e['ir.attachment'].sudo().browse(data['archive_attachment']).raw.decode()}
    (root/'archive-survival-before.json').write_text(json.dumps(before,indent=2)+'\n')
    e['ir.module.module'].search([('name','in',['company_document_cutover','company_document_purchase_cutover'])]).button_immediate_uninstall()
    e.cr.commit()
    print('PASS: native uninstall on the backed-up synthetic clone.')
else:
    before = json.loads((root/'archive-survival-before.json').read_text())
    assert before['ids'] == {m:e[m].search([],order='id').ids for m in models}
    assert before['archive_raw'] == e['ir.attachment'].sudo().browse(data['archive_attachment']).raw.decode()
    assert before['receipt_raw'] == e['ir.attachment'].sudo().browse(before['receipt']).raw.decode()
    if phase == 'absent':
        assert 'company.document.cutover' not in e and 'company.document.purchase.archive' not in e
        result = {'status':'PASS', 'phase':phase, 'all_native_ids_unchanged':True,
            'private_historical_record_and_partial_receipt_survived':True}
    else:
        job = e['company.document.cutover'].search([('recovery_key','=',data['recovery_key'])])
        assert len(job)==1 and job.state=='partial', 'Install hook must restore the partial move automatically'
        assert len(job.purchase_archive_ids)==1
        assert job.purchase_archive_ids.attachment_id.id==data['archive_attachment']
        assert job.audit_attachment_id.id==before['receipt']
        restored_before = {'job':job.id,'archive_attachment':job.purchase_archive_ids.attachment_id.id,'state':job.state}
        steps=[]
        while job.state != 'done':
            job.action_review(); assert job.state=='ready',job.report
            job.action_execute(); assert job.state in ('partial','done'),job.report
            steps.append(job.state); e.cr.commit(); e.invalidate_all(); assert len(steps)<20
        source = e['purchase.order'].browse(data['source_po'])
        assert job._stored_link(source)['audit_only']
        assert len(job.purchase_archive_ids)==1
        for source_id,hash_ in data['source_hashes'].items():
            assert job._fingerprint(e['account.move'].browse(int(source_id)))==hash_
        assert job._fingerprint(source)==data['source_po_hash']
        for model,fields_ in data['stock_models'].items():
            old_ids=[r['id'] for r in data['stock_evidence'][model]]
            assert data['stock_evidence'][model]==json.loads(json.dumps(e[model].browse(old_ids).read(fields_),default=str)),model
        new_stock = e['stock.move'].search([('id','not in',before['ids']['stock.move'])])
        assert not new_stock.filtered(lambda m:m.state=='done')
        assert e['stock.quant']._get_available_quantity(job._target(source.order_line.product_id),
            e['stock.warehouse'].search([('company_id','=',job.target_company_id.id)],limit=1).lot_stock_id)==17
        for source_id in data['source_bills']:
            copied=e['account.move'].browse(job._stored_link(e['account.move'].browse(source_id))['target'])
            assert not copied.invoice_line_ids.purchase_line_id
            assert job._stored_link(e['account.move'].browse(source_id))['purchase_history_references']
        assert len(e['purchase.order'].search([('company_id','=',data['target'])]))==3
        assert source.id not in e['purchase.order'].search([('company_id','=',data['target'])]).ids
        e.cr.execute('SELECT account_id,sum(balance) FROM account_move_line WHERE company_id=%s AND parent_state=%s GROUP BY account_id',
            [data['target'],'posted'])
        actual={a:float(v) for a,v in e.cr.fetchall()}
        for name,value in data['expected_final_ledger'].items():assert actual.get(data['accounts'][name],0)==value,(name,actual)
        assert sum(actual.values())==0
        before_retry={m:e[m].search([('company_id','=',data['target'])]).ids for m in models if 'company_id' in e[m]._fields}
        job.action_execute()
        assert before_retry=={m:e[m].search([('company_id','=',data['target'])]).ids for m in before_retry}
        result={'status':'PASS','phase':phase,'automatic_partial_move_and_history_screen_recovery':restored_before,
            'resume_steps':steps,'no_duplicated_native_records':True,'current_stock':17,'source_unchanged':True,
            'historical_net_received':3,'historical_billed_net':2,'historical_billable':1,'old_pending_supplier_delivery':6,
            'new_history_commitments_created':0,'untouched_orders_copied_natively':3,
            'trial_balance':data['expected_final_ledger'],'profit_and_loss':199,'balance_sheet_net_profit':199,
            'ledger_balanced':True,'all_original_stock_values_quantities_and_product_values_unchanged':True}
        e.cr.commit()
    (root/('archive-survival-'+phase+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print('PASS: '+phase)
